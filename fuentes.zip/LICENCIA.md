# Autoría y licencia del contenido didáctico

**La kermés de las Ciencias Sociales**

© 2026 **Serafin Gonzalez - Adscripto**.

Los contenidos didácticos propios de esta actividad —consignas originales, preguntas, explicaciones y guías— se ofrecen bajo **Creative Commons Atribución/Reconocimiento-NoComercial-CompartirIgual 4.0 Internacional (CC BY-NC-SA 4.0)**.

Se pueden compartir y adaptar con atribución adecuada, para usos no comerciales y manteniendo la misma licencia en las adaptaciones. Al reutilizar, enlazar la obra y la licencia e indicar las modificaciones realizadas. El resumen no reemplaza los términos oficiales de la licencia.

- Obra: https://metodologia-investigacion.github.io/kermes-ics/
- Resumen en español: https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es
- Texto legal en español: https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode.es
- Texto legal oficial completo: `LICENSE`.

Atribución sugerida: «La kermés de las Ciencias Sociales», Serafin Gonzalez - Adscripto, 2026, CC BY-NC-SA 4.0. https://metodologia-investigacion.github.io/kermes-ics/

## Aporte de Emilia Correa

El juego **¿Quién lo diría?**, sus explicaciones y las cinco consignas con guías de desarrollo fueron elaborados por **Emilia Correa - Adscripta**, e integrados con reconocimiento de su autoría. Recurso original: https://claude.ai/artifact/18iLJ8dpzBBk3nSF2QAw1e . La licencia indicada para los contenidos propios de Serafin Gonzalez no se extiende automáticamente a este aporte ni a los fragmentos de terceros que contiene.

## Materiales con derechos propios

La licencia anterior no se extiende a los textos y las referencias de los autores estudiados, las fotografías de terceros, los logotipos, los iconos, las tipografías, las bibliotecas de software, el código ni los aportes o respuestas de estudiantes. No se otorga una licencia de contenido sobre los registros privados de la actividad.

- Immanuel Kant: pintura de Johann Gottlieb Becker (1768), dominio público.
- Enrique Dussel: fotografía de Ralg23, dominio público, según su declaración original.
- Immanuel Wallerstein: fotografía de Alexei Kouprianov, CC BY-SA 3.0; la versión de Commons incorpora la corrección de color de Jakuzem y Jbarta. Conserva esa licencia, sin aplicar la restricción no comercial de la actividad a esta fotografía.
- Fuentes, autores, enlaces de las fotografías y licencias originales: créditos en la trastienda de la página y en `data/credits.json` de las fuentes editables.
- Los cuatro iconos del sello se utilizan sin modificar, desde el material oficial de Creative Commons: https://creativecommons.org/mission/downloads/ .
