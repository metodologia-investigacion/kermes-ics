import {bank,rosco} from './bank';
import rawCitations from './citas.json';
import rawDevelopments from './desarrollos.json';
import resource from './recurso-emilia.json';

export const citations=rawCitations;
export const developments=rawDevelopments;
export const colleagueResource=resource;
export const stationMeta=[
 {unit:1,title:'Modernidad y Ciencias Sociales',subtitle:'Razón, modernidad e institucionalización',color:'#b83f35'},
 {unit:2,title:'Problemas epistemológicos',subtitle:'Explicar, comprender y pensar la racionalidad',color:'#28736d'},
 {unit:3,title:'Ciencias Sociales y ética',subtitle:'Instituciones, mercados, ambiente y valores',color:'#a0732f'},
 {unit:0,title:'Duelo final',subtitle:'Autores y perspectivas de las tres unidades',color:'#805a91'},
];
export const gameNames:Record<string,string>={rosco:'El rosco',ruleta:'Preguntados',citas:'¿Quién lo diría?',desarrollo:'A desarrollar'};
const resultLabels:Record<string,string>={correct:'Acierto',wrong:'Para revisar',unanswered:'Sin respuesta',pending:'Para lectura docente'};
export const resultName=(result:string)=>resultLabels[result]||result;
export function questionInfo(game:string,id:string){
 if(game==='rosco'){
  const q=rosco.find(q=>q.letter===id);
  return {prompt:q?`${q.rule==='empieza'?'Empieza con':'Contiene la'} ${q.letter}. ${q.clue}`:id,expected:q?.answer||'',source:q?.source||''};
 }
 if(game==='citas'){
  const q=citations.find(q=>q.id===id);
  return {prompt:q?`Identificá al autor o la postura: «${q.quote}»`:id,expected:q?q.options[q.correct]:'',source:q?.source||''};
 }
 if(game==='desarrollo'){
  const q=developments.find(q=>q.id===id);
  return {prompt:q?.prompt||id,expected:q?'Criterios para la lectura: '+q.keys.join(' · '):'',source:q?.citations.map(c=>c.source).join(' | ')||''};
 }
 const q=bank.find(q=>q.id===id);
 return {prompt:q?.prompt||id,expected:q?q.options[q.correct]:'',source:q?.source||''};
}
export function frequentConfusions(attempts:{game:string;question:string;answer:string;result:string}[]){
 const grouped=new Map<string,{chosen:string;expected:string;count:number}>();
 for(const a of attempts){
  if(a.game!=='citas'||a.result!=='wrong')continue;
  const q=citations.find(q=>q.id===a.question);if(!q)continue;
  const expected=q.options[q.correct],key=JSON.stringify([a.answer,expected]);
  const prev=grouped.get(key);grouped.set(key,{chosen:a.answer,expected,count:(prev?.count||0)+1});
 }
 return [...grouped.values()].sort((a,b)=>b.count-a.count||a.expected.localeCompare(b.expected,'es'));
}
