import {build} from 'vite';
import react from '@vitejs/plugin-react';
import {mkdir,readFile,writeFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const entry=path.join(root,'.sites-runtime','github-entry');
const destination=path.resolve(process.argv[2]||path.join(root,'github-dist'));
await mkdir(entry,{recursive:true});
await mkdir(destination,{recursive:true});
const assets={};
for(const file of await readdir(path.join(root,'public','authors'))){
 if(file.endsWith('.jpg'))assets['/authors/'+file]='data:image/jpeg;base64,'+(await readFile(path.join(root,'public','authors',file))).toString('base64');
}
const favicon='data:image/svg+xml;base64,'+(await readFile(path.join(root,'public','favicon.svg'))).toString('base64');
for(const file of await readdir(path.join(root,'public','license'))){
 if(file.endsWith('.svg'))assets['/license/'+file]='data:image/svg+xml;base64,'+(await readFile(path.join(root,'public','license',file))).toString('base64');
}
await writeFile(path.join(entry,'index.html'),'<!doctype html><html lang="es-AR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="description" content="Rosco, Preguntados y muro colectivo para repasar Introducción a las Ciencias Sociales."><meta name="author" content="Serafin Gonzalez - Adscripto"><link rel="license" href="https://creativecommons.org/licenses/by-nc-sa/4.0/"><meta name="referrer" content="strict-origin-when-cross-origin"><title>La kermés de las Ciencias Sociales</title><link rel="icon" href="'+favicon+'"></head><body><div id="root"></div><script type="module" src="./main.tsx"></script></body></html>');
await writeFile(path.join(entry,'main.tsx'),"import React from 'react';import {createRoot} from 'react-dom/client';import Home from '../../app/page';import '../../app/globals.css';import '../../app/arcade.css';import '../../app/async.css';import '../../app/rosco-polish.css';import '../../app/license.css';createRoot(document.getElementById('root')!).render(<Home/>);");
const result=await build({
 configFile:false,root:entry,base:'./',publicDir:false,plugins:[react()],
 define:{__ICS_API_ORIGIN__:JSON.stringify('https://kermes-ics-serafin.sgonzalez372.chatgpt.site'),__ICS_ASSETS__:JSON.stringify(assets)},
 css:{postcss:{plugins:[]}},
 build:{write:false,sourcemap:false,cssCodeSplit:false,chunkSizeWarningLimit:3000,rollupOptions:{output:{inlineDynamicImports:true}}},
});
const output=Array.isArray(result)?result[0].output:result.output;
let html=output.find(file=>file.fileName==='index.html').source;
for(const file of output){
 if(file.type==='chunk')html=html.replace(/<script\b[^>]*src="[^"]+"[^>]*><\/script>/,()=>'<script type="module">'+file.code.replace(/<\/script/gi,'<\\/script')+'</script>');
 if(file.fileName.endsWith('.css'))html=html.replace(/<link\b[^>]*href="[^\"]+\.css"[^>]*>/,()=>'<style>'+String(file.source)+'</style>');
}
if(/(?:src|href)="\.\/assets\//.test(html))throw new Error('An asset was not embedded.');
await writeFile(path.join(destination,'index.html'),html);
await writeFile(path.join(destination,'.nojekyll'),'');
console.log('GitHub Pages: index.html preparado ('+Buffer.byteLength(html)+' bytes).');
