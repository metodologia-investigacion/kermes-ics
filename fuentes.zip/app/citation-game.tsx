'use client';
import {useEffect,useRef,useState} from 'react';
import {ArrowLeft,ArrowRight,BookOpen,Check,ChevronRight,Lock,PenLine,Quote,RotateCw} from 'lucide-react';
import {citations,developments,stationMeta,colleagueResource,frequentConfusions} from '../data/activities';
import {normalize} from '../data/bank';
import {useGame} from './student-games';
import type {StudentAttempt} from './student-activity';

type Answer={selected:number;id:string};
type CitationState={active:number|null;positions:Record<string,number>;sessions:Record<string,string>;answers:Record<string,Answer>;drafts:Record<string,number>;orders:Record<string,number[]>};
type EssayState={session:string;drafts:Record<string,string>;checks:Record<string,number[]>;last:Record<string,{id:string;text:string;checks:string}>};
type Props={stateKey:string;record:(event:any)=>string;point:(n:number,t?:string)=>void;team:string;attempts:StudentAttempt[];queueCount:number;onProgress:()=>void};
const freshCitations=():CitationState=>({active:null,positions:{},sessions:{},answers:{},drafts:{},orders:{}});
const freshEssays=():EssayState=>({session:'',drafts:{},checks:{},last:{}});
const shuffled=(length:number)=>{const a=Array.from({length},(_,i)=>i);for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};

export default function CitationGame({stateKey,record,point,team,attempts,queueCount,onProgress}:Props){
 const [g,setG,ready]=useGame<CitationState>('ics-citas-v1-'+stateKey,freshCitations());
 const [essays,setEssays,essaysReady]=useGame<EssayState>('ics-desarrollos-v1-'+stateKey,freshEssays());
 const [tab,setTab]=useState<'estaciones'|'escritura'>('estaciones'),[openGuide,setOpenGuide]=useState<string[]>([]),[notice,setNotice]=useState('');
 const startedAt=useRef(Date.now()),answerLock=useRef(''),essayLock=useRef(''),panel=useRef<HTMLDivElement>(null);
 const active=g.active===null?null:stationMeta.find(s=>s.unit===g.active);
 const list=active?citations.filter(q=>q.unit===active.unit):[];
 const pos=active?g.positions[String(active.unit)]||0:0;
 const q=list[pos],saved=q?g.answers[q.id]:undefined;
 const confusion=frequentConfusions(attempts);
 useEffect(()=>{startedAt.current=Date.now();answerLock.current='';panel.current?.focus({preventScroll:true})},[q?.id,tab]);
 if(!ready||!essaysReady)return <p className="game-loading" role="status">Recuperando tus citas y borradores…</p>;
 function start(unit:number,repeat=false){
  const key=String(unit),questions=citations.filter(q=>q.unit===unit);
  setG(old=>{const answers={...old.answers},drafts={...old.drafts},orders={...old.orders};for(const item of questions){if(repeat){delete answers[item.id];delete drafts[item.id]}if(repeat||!orders[item.id])orders[item.id]=shuffled(item.options.length)}return {...old,active:unit,positions:{...old.positions,[key]:repeat?0:old.positions[key]||0},sessions:{...old.sessions,[key]:repeat||!old.sessions[key]?crypto.randomUUID():old.sessions[key]},answers,drafts,orders}});
  setTab('estaciones');setNotice('');
 }
 function sendCitation(){
  if(!q||saved||g.drafts[q.id]===undefined||answerLock.current===q.id)return;
  answerLock.current=q.id;
  const selected=g.drafts[q.id],id=record({id:crypto.randomUUID(),session:g.sessions[String(q.unit)],game:'citas',question:q.id,selected,team,seconds:Math.round((Date.now()-startedAt.current)/1000)});
  setG(s=>({...s,answers:{...s.answers,[q.id]:{selected,id}}}));
  if(selected===q.correct)point(1,team);
 }
 function sendEssay(id:string){
  const item=developments.find(q=>q.id===id);if(!item)return;
  const text=(essays.drafts[id]||'').trim(),checks=(essays.checks[id]||[]).map(i=>item.checklist[i]).filter(Boolean).join(' · '),signature=JSON.stringify([id,text,checks]);
  if(text.length<40||text.length>5000||signature===essayLock.current)return;
  if(essays.last[id]?.text===text&&essays.last[id]?.checks===checks)return;
  essayLock.current=signature;
  const session=essays.session||crypto.randomUUID();
  const attemptId=record({id:crypto.randomUUID(),session,game:'desarrollo',question:id,answer:text,reasoning:checks?'Autoevaluación del estudiante: '+checks:'',team,seconds:0});
  setEssays(s=>({...s,session,last:{...s.last,[id]:{id:attemptId,text,checks}}}));
  setOpenGuide(s=>s.includes(id)?s:[...s,id]);
  setNotice('Respuesta incorporada al envío. La guía ya está disponible. Comprobá que no queden registros pendientes antes de cerrar.');
 }
 return <section className="citation-game">
  <div className="citation-heading"><div><p className="eyebrow">Puesto 03 · Las voces de las ideas</p><h1>¿Quién lo diría?</h1><p>Reconocé autores y posturas. Después, pasá de elegir una opción a construir una respuesta.</p></div><span className="colleague-credit">Recurso de <b>Emilia Correa · Adscripta</b><a href={colleagueResource.source} target="_blank" rel="noreferrer">Ver el recurso original <ArrowRight size={12}/></a></span></div>
  <div className="citation-tabs" role="group" aria-label="Recorridos del puesto"><button className={tab==='estaciones'?'selected':''} onClick={()=>setTab('estaciones')}><Quote size={17}/> Citas y posturas <span>40</span></button><button className={tab==='escritura'?'selected':''} onClick={()=>setTab('escritura')}><PenLine size={17}/> A desarrollar <span>5</span></button><button onClick={onProgress}><Lock size={15}/> Mis envíos</button></div>
  <p className="citation-privacy"><Lock size={14}/> Participación anónima · Las opciones y los desarrollos quedan para docentes. El muro es el espacio compartido.</p>
  {queueCount>0&&<p className="pending-save" role="status">Hay {queueCount} registro(s) pendientes de sincronizar. Se conservan en este navegador.</p>}
  {tab==='estaciones'&&<>
   {!active?<>
    <div className="citation-welcome"><span className="quote-emblem">“</span><div><h2>Una frase. Varias voces posibles.</h2><p>Elegí una estación. Leé el fragmento y seleccioná al autor o la postura que lo expresa. Enviá tu elección para ver la explicación, la confusión que conviene revisar y dónde volver a leer.</p><p>Las opciones cambian de orden en cada nueva vuelta. Sin reloj y sin nota automática. Podés salir y retomar en este navegador.</p></div></div>
    <div className="citation-stations">{stationMeta.map(s=>{const items=citations.filter(q=>q.unit===s.unit),answered=items.filter(q=>g.answers[q.id]).length;return <button key={s.unit} className="citation-station" style={{'--station-color':s.color} as React.CSSProperties} onClick={()=>start(s.unit)}><span className="station-token">{s.unit?'U'+s.unit:'✦'}</span><h3>{s.title}</h3><p>{s.subtitle}</p><small>{items.length} fragmentos · {answered} recorridos en esta vuelta</small><b>{answered?'Retomar estación':'Entrar a la estación'} <ArrowRight size={17}/></b></button>})}</div>
    <Confusions rows={confusion} />
    <button className="development-invitation" onClick={()=>setTab('escritura')}><PenLine size={24}/><span><b>Para cerrar: a desarrollar</b><small>Cinco consignas con guías de revisión y espacio para escribir.</small></span><ArrowRight/></button>
   </>:<>
    <div className="citation-station-bar"><button className="text-btn" onClick={()=>setG(s=>({...s,active:null}))}><ArrowLeft size={16}/> Todas las estaciones</button><span>{active.title}</span><b>{Math.min(pos+1,list.length)} / {list.length}</b></div>
    {!q?<div className="citation-summary"><p className="eyebrow">Una vuelta más, una mirada más fina</p><h2>Estación recorrida.</h2><b className="citation-total">{list.filter(q=>g.answers[q.id]?.selected===q.correct).length} <small>aciertos de {list.length}</small></b><p>El resultado orienta qué volver a leer. Las repeticiones quedan guardadas como intentos nuevos.</p><Confusions rows={frequentConfusions(list.filter(q=>g.answers[q.id]).map(q=>({game:'citas',question:q.id,answer:q.options[g.answers[q.id].selected],result:g.answers[q.id].selected===q.correct?'correct':'wrong'})))}/><div className="actions"><button className="btn" onClick={()=>start(active.unit,true)}><RotateCw size={16}/> Repetir estación</button><button className="btn outline" onClick={()=>setG(s=>({...s,active:null}))}>Elegir otra estación</button><button className="btn outline" onClick={()=>setTab('escritura')}>Pasar a desarrollar <ArrowRight size={16}/></button></div></div>:<div className="citation-round" ref={panel} tabIndex={-1}>
     <article className="citation-ticket"><p className="eyebrow">¿De quién es este fragmento?</p><blockquote>{q.quote}</blockquote><p className="citation-unit">{q.unit?'Unidad '+q.unit:'Duelo de las tres unidades'} · Recurso de Emilia Correa</p></article>
     <div className="citation-choices" role="radiogroup" aria-label="Autores y posturas">{(g.orders[q.id]||q.options.map((_,i)=>i)).map((index,display)=><button key={index} role="radio" aria-checked={(saved?.selected??g.drafts[q.id])===index} disabled={!!saved} className={'citation-option '+(saved?(index===q.correct?'right':index===saved.selected?'wrong':'dim'):g.drafts[q.id]===index?'picked':'')} onClick={()=>setG(s=>({...s,drafts:{...s.drafts,[q.id]:index}}))}><span>{String.fromCharCode(65+display)}</span><b>{q.options[index]}</b><small>{q.optionUnits[index]}</small>{saved&&index===q.correct&&<Check size={18}/>}</button>)}</div>
     {!saved?<button className="btn citation-send" disabled={g.drafts[q.id]===undefined} onClick={sendCitation}>Enviar elección y ver explicación <ArrowRight size={17}/></button>:<div className={'citation-feedback '+(saved.selected===q.correct?'yes':'no')} role="status"><p className="eyebrow">{saved.selected===q.correct?'Bien reconocido':'Una diferencia para volver a pensar'}</p><h3>{q.options[q.correct]}</h3><p>{q.explanation}</p><div className="confusion-note"><b>La distinción que importa</b><p>{q.confusion}</p></div><p className="citation-followup">{q.followup}</p><p className="citation-source"><BookOpen size={16}/><span><b>Dónde leerlo</b>{q.source}</span></p><button className="btn" onClick={()=>setG(s=>({...s,positions:{...s.positions,[String(q.unit)]:pos+1}}))}>{pos===list.length-1?'Ver balance de la estación':'Siguiente fragmento'} <ChevronRight size={17}/></button></div>}
    </div>}
   </>}
  </>}
  {tab==='escritura'&&<div className="development-workshop"><div className="development-intro"><p className="eyebrow">Del reconocimiento al argumento</p><h2>Para cerrar: a desarrollar.</h2><p>Primero escribí sin abrir la guía. Enviá una primera versión para habilitar los criterios, las referencias y los errores frecuentes. Después podés revisar y enviar otra versión.</p><p>Los borradores quedan en este navegador. Los envíos se guardan para docentes y requieren lectura: no reciben un acierto o un error automático.</p></div>{notice&&<p className="confirmed-save" role="status">{notice}</p>}
   {developments.map(item=>{const text=essays.drafts[item.id]||'',last=essays.last[item.id],previous=attempts.some(a=>a.game==='desarrollo'&&a.question===item.id),unlocked=!!last||previous,checked=essays.checks[item.id]||[],checks=checked.map(i=>item.checklist[i]).join(' · '),unchanged=last?.text===text.trim()&&last?.checks===checks,expanded=openGuide.includes(item.id);return <article key={item.id} className="development-card"><div className="development-question"><span className="tag">U{item.unit}</span><h3>{item.title}</h3><p>{item.prompt}</p></div><div className="development-writing"><label htmlFor={'essay-'+item.id}>Tu desarrollo</label><textarea id={'essay-'+item.id} rows={8} value={text} maxLength={5000} placeholder="Empezá por definir los conceptos y sostener la comparación con un ejemplo…" onChange={e=>setEssays(s=>({...s,drafts:{...s.drafts,[item.id]:e.target.value}}))}/><div className="development-actions"><small>{text.length} / 5000 caracteres · Borrador guardado en este navegador</small><button className="btn" disabled={text.trim().length<40||unchanged} onClick={()=>sendEssay(item.id)}>{last?'Enviar nueva versión':'Enviar respuesta y abrir la guía'} <ArrowRight size={16}/></button></div>{unlocked?<button className="text-btn guide-toggle" aria-expanded={expanded} onClick={()=>setOpenGuide(s=>s.includes(item.id)?s.filter(id=>id!==item.id):[...s,item.id])}><BookOpen size={16}/>{expanded?'Ocultar guía':'Abrir guía de revisión'}</button>:<p className="guide-locked"><Lock size={14}/> La guía se habilita después de enviar tu primera respuesta, desde 40 caracteres.</p>}
    {unlocked&&expanded&&<div className="development-guide"><h4>¿Tu respuesta incluye…?</h4><ul className="self-checks">{item.checklist.map((line,i)=><li key={line}><label><input type="checkbox" checked={checked.includes(i)} onChange={()=>setEssays(s=>({...s,checks:{...s.checks,[item.id]:checked.includes(i)?checked.filter(n=>n!==i):[...checked,i]}}))}/>{line}</label></li>)}</ul><h4>Ideas que tiene que desarrollar</h4><ul>{item.keys.map(line=><li key={line}>{line}</li>)}</ul><h4>Fragmentos y referencias para fundamentar</h4>{item.citations.map((c,i)=><figure key={i}><blockquote>{c.quote}</blockquote><figcaption>{c.source}</figcaption></figure>)}<h4>Errores frecuentes</h4><ul>{item.errors.map(line=><li key={line}>{line}</li>)}</ul><p className="note">Las casillas son una autoevaluación. Al enviar una nueva versión se conservan junto con ella; no producen una nota automática.</p></div>}
   </div></article>})}
  </div>}
 </section>;
}

export function Confusions({rows}:{rows:{chosen:string;expected:string;count:number}[]}){return <section className="citation-confusions"><h3>Posturas que conviene volver a contrastar</h3>{rows.length?<ul>{rows.slice(0,8).map(row=><li key={JSON.stringify([row.chosen,row.expected])}><span>Elegiste <b>{row.chosen}</b> donde correspondía <b>{row.expected}</b>.</span><small>{row.count} {row.count===1?'vez':'veces'}</small></li>)}</ul>:<p>Cuando aparezcan diferencias en tus elecciones, acá vas a ver qué perspectivas conviene releer juntas.</p>}</section>}

export function ColleagueLibrary({search,unit,reveal}:{search:string;unit:string;reveal:boolean}){
 const matches=(u:number,text:string)=>(unit==='all'||u===Number(unit))&&normalize(text).includes(normalize(search));
 const questions=citations.filter(q=>matches(q.unit,q.quote+' '+q.options.join(' ')+' '+q.source)),essays=developments.filter(q=>matches(q.unit,q.prompt+' '+q.title));
 return <div className="colleague-library"><h2>¿Quién lo diría? y A desarrollar</h2><p>Recurso de <b>Emilia Correa · Adscripta</b>. {questions.length} fragmentos y {essays.length} consignas coinciden con estos filtros. <a href={colleagueResource.source} target="_blank" rel="noreferrer">Recurso original</a>.</p>{questions.map(q=><details className="library-item" key={q.id}><summary><span className="tag">{q.unit?'U'+q.unit:'Duelo'}</span> «{q.quote}»</summary><div>{q.options.map((option,i)=><p key={option}>{String.fromCharCode(65+i)}. {option}{reveal&&i===q.correct?' ✓':''}</p>)}{reveal&&<><p>{q.explanation}</p><p>{q.confusion}</p></>}<small>Fuente: {q.source}</small></div></details>)}{essays.map(q=><details className="library-item" key={q.id}><summary><span className="tag">U{q.unit} · Desarrollo</span> {q.prompt}</summary><div>{reveal&&<ul>{q.keys.map(line=><li key={line}>{line}</li>)}</ul>}<small>Referencias: {q.citations.map(c=>c.source).join(' · ')}</small></div></details>)}</div>;
}
