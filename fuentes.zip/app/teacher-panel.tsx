'use client';

import {useEffect,useRef,useState} from 'react';
import {ArrowRight,BarChart3,ChevronLeft,ChevronRight,Copy,Download,Lock,RotateCw,Unlock} from 'lucide-react';
import {gameNames,questionInfo,resultName,frequentConfusions} from '../data/activities';
import {classroomURL,siteURL} from './runtime-config';

type Room={code:string;name:string;open:number};
type Participant={id:string;name:string;group:string;created:string};
type Attempt={id:string;room:string;session:string;team:string;game:string;question:string;unit:number;category:string;result:string;answer:string;manual:number;bonus:number;seconds:number;created:string;participant:string|null;reasoning:string};
type Props={room:Room|null;teacherKey:string;onManage:()=>void;refresh:()=>unknown|Promise<unknown>;copy:(text:string)=>unknown;studentURL:()=>string;tell:(text:string)=>void;queueCount:number};
type Stats={room:Room;attempts:Attempt[];participants:Participant[]};

const resultLabel=resultName;
const anonymousAlias=(p:Participant)=>/^Participante [A-F0-9]{6}$/.test(p.name)?p.name:'Participante '+p.id.slice(0,6).toUpperCase();
const dateLabel=(value:string)=>new Date(value).toLocaleString('es-AR',{timeZone:'America/Argentina/Buenos_Aires',dateStyle:'short',timeStyle:'short'});
function questionFor(a:Attempt){return questionInfo(a.game,a.question)}
function AnswerText({text}:{text:string}){return text.length>380?<div><b>Respuesta:</b><details><summary>Leer respuesta completa ({text.length} caracteres)</summary><p style={{whiteSpace:'pre-wrap'}}>{text}</p></details></div>:<p style={{whiteSpace:'pre-wrap'}}><b>Respuesta:</b> {text||'Sin respuesta'}</p>}
function csvCell(value:unknown){
 let text=String(value??'');
 if(/^[\s\u0000-\u001f]*[=+\-@]/u.test(text))text="'"+text;
 return '"'+text.replace(/"/g,'""')+'"';
}
function saveCsv(name:string,rows:unknown[][]){
 const content='\ufeff'+rows.map(row=>row.map(csvCell).join(';')).join('\r\n');
 const url=URL.createObjectURL(new Blob([content],{type:'text/csv;charset=utf-8'}));
 const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}

export default function Teacher({room,teacherKey,onManage,refresh,copy,studentURL,tell,queueCount}:Props){
 const[data,setData]=useState<Attempt[]>([]),[participants,setParticipants]=useState<Participant[]>([]),[loadedFor,setLoadedFor]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false),[reviewing,setReviewing]=useState(''),[game,setGame]=useState('all'),[person,setPerson]=useState('all'),[page,setPage]=useState(0),[teacherLink,setTeacherLink]=useState(''),[showTeacher,setShowTeacher]=useState(false);
 const request=useRef(0),detail=useRef<HTMLDivElement>(null);
 const accessIdentity=room?.code+'|'+teacherKey;
 async function api(method:string,body?:Record<string,unknown>,query=''){
  const response=await fetch(classroomURL(query),{method,headers:{'Content-Type':'application/json','X-Teacher-Key':teacherKey},...(body?{body:JSON.stringify(body)}:{})});
  const result:unknown=await response.json();
  if(!response.ok)throw new Error(typeof result==='object'&&result&&'error' in result?String(result.error):'No se pudo completar la acción.');
  return result;
 }
 async function load(){
  const ticket=++request.current;if(!room||!teacherKey){setData([]);setParticipants([]);setLoadedFor('');return}
  setBusy(true);setError('');
  try{
   const response=await api('GET',undefined,'?room='+encodeURIComponent(room.code)+'&view=stats') as Stats;
   if(ticket!==request.current)return;
   setData(response.attempts||[]);setParticipants(response.participants||[]);setLoadedFor(accessIdentity);
  }catch(e){if(ticket===request.current){setError((e as Error).message);setLoadedFor('');setData([]);setParticipants([])}}
  finally{if(ticket===request.current)setBusy(false)}
 }
 useEffect(()=>{setGame('all');setPerson('all');setPage(0);setShowTeacher(false);load();return()=>{request.current++}},[room?.code,teacherKey]);
 useEffect(()=>{setTeacherLink(room&&teacherKey?siteURL()+'?sala='+room.code+'#docente='+teacherKey:'')},[room?.code,teacherKey]);
 useEffect(()=>setPage(0),[game,person]);
 const authorized=!!room&&!!teacherKey&&loadedFor===accessIdentity;
 const safeData=authorized?data:[],safeParticipants=authorized?participants:[];
 const people=new Map(safeParticipants.map(p=>[p.id,p]));
 const rows=safeData.filter(a=>(game==='all'||a.game===game)&&(person==='all'||(person==='legacy'?!a.participant:a.participant===person)));
 const mixups=frequentConfusions(rows),pending=rows.filter(a=>a.result==='pending'&&!a.bonus).length;
 const correct=rows.filter(a=>a.result==='correct').length,wrong=rows.filter(a=>a.result==='wrong').length,unanswered=rows.filter(a=>a.result==='unanswered').length;
 const legacy=safeData.filter(a=>!a.participant),pageSize=25,maxPage=Math.max(0,Math.ceil(rows.length/pageSize)-1),visiblePage=Math.min(page,maxPage),visibleRows=rows.slice(visiblePage*pageSize,(visiblePage+1)*pageSize);
 const summaries=safeParticipants.map(p=>{
  const all=safeData.filter(a=>a.participant===p.id),answered=all.filter(a=>a.result!=='unanswered');
  return {p,all,rosco:new Set(answered.filter(a=>a.game==='rosco').map(a=>a.question)).size,ruleta:new Set(answered.filter(a=>a.game==='ruleta').map(a=>a.question)).size,citas:new Set(answered.filter(a=>a.game==='citas').map(a=>a.question)).size,desarrollo:new Set(answered.filter(a=>a.game==='desarrollo').map(a=>a.question)).size,sessions:new Set(all.map(a=>a.session)).size,correct:all.filter(a=>a.result==='correct').length,unanswered:all.filter(a=>a.result==='unanswered').length};
 }).sort((a,b)=>anonymousAlias(a.p).localeCompare(anonymousAlias(b.p),'es')||a.p.id.localeCompare(b.p.id));
 function showPerson(id:string){setPerson(id);setGame('all');setPage(0);detail.current?.scrollIntoView({behavior:'smooth',block:'start'})}
 function exportResults(){
  if(!room)return;
  const headers=['id_registro','fecha_UTC','sala','participante_id','alias_anonimo','sesion','juego','pregunta_id','pregunta_completa','respuesta_esperada','unidad','categoria','resultado','respuesta','fundamentacion','correccion_docente','fundamentacion_lograda','desarrollo_leido','segundos_en_esta_visita_de_la_pregunta'];
  const lines=safeData.map(a=>{const p=a.participant?people.get(a.participant):null,q=questionFor(a);return [a.id,a.created,a.room,a.participant||'',p?anonymousAlias(p):a.participant?'Participante '+a.participant.slice(0,6).toUpperCase():'Registro anterior '+a.id.slice(0,8),a.session,a.game,a.question,q.prompt,q.expected,a.unit||'Cruce',a.category,a.result,a.answer,a.reasoning||'',a.manual,a.game==='desarrollo'?'':a.bonus,a.game==='desarrollo'?a.bonus:'',a.game==='desarrollo'?'':a.seconds]});
  saveCsv('ICS_resultados_completos_'+room.code+'.csv',[headers,...lines]);
 }
 async function lock(){if(!room)return;try{await api('PATCH',{action:'lock',room:room.code,open:!room.open});await refresh();tell(room.open?'Sala cerrada. Los registros y el muro siguen disponibles.':'La sala vuelve a recibir respuestas y aportes.')}catch(e){tell((e as Error).message)}}
 async function review(a:Attempt,action:'manual'|'bonus'){
  if(!room)return;setReviewing(a.id);
  try{await api('PATCH',{action,room:room.code,id:a.id});await load();tell(action==='manual'?'Variante aceptada y marcada como corrección docente.':'Fundamentación marcada como lograda.')}
  catch(e){tell((e as Error).message)}finally{setReviewing('')}
 }
 return <>
  <div className="page-title"><p className="eyebrow">Seguimiento de la actividad virtual</p><h1>Espacio docente</h1><p>Respuestas individuales y fundamentaciones para recuperar después del repaso.</p></div>
  {!room||!teacherKey?<section className="empty teacher-empty"><BarChart3 size={42}/><h2>El recorrido queda guardado.</h2><p>Ingresá con el enlace docente de tu sala para consultar los recorridos y las respuestas de cada participación anónima. Los participantes sólo ven sus propios resultados; el muro es compartido.</p><button className="btn" onClick={onManage}>Crear o recuperar una sala <ArrowRight size={17}/></button><p className="note">Si sos colega, abrí el acceso docente que te compartieron. El enlace estudiantil no permite consultar estas estadísticas.</p></section>:<section className="teacher-panel">
   <div className="teacher-tools"><div><h2>{room.name}</h2><p>Código de sala <b className="code">{room.code}</b></p></div><div className="actions"><button className="btn outline" onClick={load} disabled={busy}><RotateCw size={16}/>{busy?'Cargando…':'Actualizar datos'}</button><button className="btn outline" onClick={lock} disabled={!authorized}>{room.open?<Lock size={16}/>:<Unlock size={16}/>} {room.open?'Cerrar recepción':'Reabrir sala'}</button></div></div>
   <div className="sharing"><div><p className="eyebrow">Para el aula virtual</p><p>Compartí este enlace con estudiantes. Entrarán sin dar su nombre. El sistema asigna un código anónimo para guardar cada recorrido.</p><input aria-label="Enlace estudiantil" readOnly value={studentURL()}/><button className="text-btn" onClick={()=>copy(studentURL())}><Copy size={14}/> Copiar enlace estudiantil</button></div><div><p className="eyebrow">Sólo para docentes</p><p>Guardá el acceso a respuestas, estadísticas y controles.</p><input aria-label="Enlace docente privado" type={showTeacher?'text':'password'} readOnly value={teacherLink}/><button className="text-btn" onClick={()=>copy(teacherLink)}><Copy size={14}/> Copiar acceso docente</button> <button className="text-btn" onClick={()=>setShowTeacher(!showTeacher)}>{showTeacher?'Ocultar enlace':'Mostrar enlace'}</button><small>Compartilo únicamente con colegas: permite administrar la sala y ver las respuestas individuales.</small></div></div>
   {error&&<p className="error" role="alert">{error}</p>}{queueCount>0&&<p className="error">Quedan {queueCount} registros pendientes de este dispositivo. Revisá el aviso de sincronización antes de cerrar la actividad.</p>}
   {!authorized&&!error?<div className="empty"><p>Verificando el acceso docente y recuperando los registros…</p></div>:authorized&&<>
    <div className="teacher-roster analytics-box"><div className="section-heading"><div><h3>Recorrido por participación anónima</h3><p>{safeParticipants.length} participaciones anónimas. Los recuentos incluyen los tres juegos, los desarrollos y todas las sesiones de cada código.</p></div><button className="btn" onClick={exportResults} disabled={!safeData.length}><Download size={16}/> Descargar todos los registros (CSV)</button></div>
     {summaries.length===0?<p>Todavía no hay participaciones. El registro se crea al comenzar, sin pedir nombre ni comisión.</p>:<div className="table-wrap"><table><thead><tr><th>Participación anónima</th><th>Rosco</th><th>Preguntados</th><th>¿Quién lo diría?</th><th>Desarrollos</th><th>Sesiones</th><th>Aciertos</th><th>Sin respuesta</th><th>Detalle</th></tr></thead><tbody>{summaries.map(({p,all,rosco:rc,ruleta,citas:ct,desarrollo:ds,sessions,correct:ok,unanswered:no})=><tr key={p.id}><td style={{whiteSpace:'normal'}}><b>{anonymousAlias(p)}</b><small className="participant-reference" style={{display:'block'}}>Código asignado al azar</small></td><td>{rc}/24 letras</td><td>{ruleta} preguntas distintas</td><td>{ct}/40 fragmentos</td><td>{ds}/5 consignas</td><td>{sessions}</td><td>{ok}</td><td>{no}</td><td><button className="text-btn" onClick={()=>showPerson(p.id)} disabled={!all.length}>Ver respuestas <ChevronRight size={14}/></button></td></tr>)}</tbody></table></div>}
     <p className="note">El avance cuenta preguntas o letras distintas efectivamente respondidas, aunque la respuesta sea incorrecta. Las repeticiones no incrementan ese avance; sí se conservan como nuevos intentos y sesiones. Las letras cerradas sin contestar no cuentan como respondidas.</p>
    </div>
    {legacy.length>0&&<div className="analytics-box legacy-records"><h3>Registros anteriores</h3><p>Se conservaron {legacy.length} intentos de la modalidad anterior, sin identificación personal. Se mantienen separados de las participaciones anónimas actuales.</p><button className="text-btn" onClick={()=>showPerson('legacy')}>Ver registros anteriores <ChevronRight size={14}/></button></div>}
    {mixups.length>0&&<section className="teacher-confusions"><h3>Posturas que conviene volver a contrastar</h3><p>Según las elecciones de ¿Quién lo diría? para los filtros actuales.</p><ul>{mixups.slice(0,12).map(m=><li key={JSON.stringify([m.chosen,m.expected])}>Se eligió <b>{m.chosen}</b> donde correspondía <b>{m.expected}</b>: {m.count} {m.count===1?'vez':'veces'}.</li>)}</ul></section>}<div ref={detail} className="teacher-detail analytics-box" style={{scrollMarginTop:20}}><h3>Respuestas y fundamentaciones</h3><div className="stats-controls"><label>Juego<select value={game} onChange={e=>setGame(e.target.value)}><option value="all">Todos los puestos</option><option value="rosco">Rosco</option><option value="ruleta">Preguntados</option><option value="citas">¿Quién lo diría?</option><option value="desarrollo">A desarrollar</option></select></label><label>Participación anónima<select value={person} onChange={e=>setPerson(e.target.value)}><option value="all">Todas las participaciones y registros</option>{summaries.map(({p})=><option key={p.id} value={p.id}>{anonymousAlias(p)}</option>)}{legacy.length>0&&<option value="legacy">Registros anteriores</option>}</select></label><button className="text-btn" onClick={()=>{setGame('all');setPerson('all')}}>Quitar filtros</button></div>
     <div className="stat-cards"><div><small>Intentos de esta selección</small><b>{rows.length}</b></div><div><small>Aciertos</small><b>{correct}</b></div><div><small>Errores</small><b>{wrong}</b></div><div><small>Sin respuesta</small><b>{unanswered}</b></div><div><small>Desarrollos por leer</small><b>{pending}</b></div></div>
     {rows.length===0?<p>No hay respuestas para los filtros elegidos.</p>:<><div className="table-wrap"><table className="attempt-detail-table"><thead><tr><th>Participación y fecha</th><th>Juego</th><th>Pregunta completa</th><th>Respuesta y fundamentación</th><th>Revisión docente</th></tr></thead><tbody>{visibleRows.map(a=>{const p=a.participant?people.get(a.participant):null,q=questionFor(a);return <tr key={a.id}><td style={{whiteSpace:'normal',minWidth:150}}><b>{p?anonymousAlias(p):a.participant?'Participante '+a.participant.slice(0,6).toUpperCase():'Registro anterior '+a.id.slice(0,8)}</b><small style={{display:'block'}}>{dateLabel(a.created)}</small><small style={{display:'block'}}>Sesión {a.session.slice(0,8)}</small></td><td style={{whiteSpace:'normal',minWidth:100}}>{gameNames[a.game]||a.game}<small style={{display:'block'}}>{a.unit?'Unidad '+a.unit:'Cruces'}</small><small style={{display:'block'}}>{a.game==='desarrollo'?'Desarrollo sin cronómetro':a.seconds+' segundos en esta visita de la pregunta'}</small></td><td className="attempt-question" style={{whiteSpace:'normal',minWidth:260,maxWidth:410}}><p>{q.prompt}</p><small>Referencia: {q.source}</small></td><td className="attempt-text" style={{whiteSpace:'normal',minWidth:260,maxWidth:420}}><AnswerText text={a.answer}/><p><b>Resultado:</b> {a.result==='pending'&&a.bonus===1?'Lectura docente marcada':resultLabel(a.result)}{a.manual?' · variante aceptada por docente':''}</p>{a.game==='desarrollo'?<details><summary>Criterios de lectura docente</summary><p><small>{q.expected}</small></p></details>:<p><small>Respuesta prevista: {q.expected}</small></p>}<p style={{whiteSpace:'pre-wrap'}}><b>Fundamentación:</b> {a.reasoning||'No se registró fundamentación escrita.'}</p></td><td style={{whiteSpace:'normal',minWidth:190}}>{a.manual===1&&<p className="tag">Variante revisada</p>}{a.game==='rosco'&&a.result==='wrong'&&<button className="btn outline" style={{fontSize:12}} disabled={reviewing===a.id} onClick={()=>review(a,'manual')}>Aceptar como variante equivalente</button>}{a.game==='desarrollo'&&(a.bonus===1?<p className="tag">Lectura docente marcada</p>:<button className="btn outline" style={{fontSize:12}} disabled={reviewing===a.id} onClick={()=>review(a,'bonus')}>Marcar desarrollo como leído</button>)}{a.reasoning&&a.game!=='desarrollo'&&<>{a.bonus===1?<p className="tag">Fundamentación lograda</p>:<button className="btn outline" style={{fontSize:12,marginTop:10}} disabled={reviewing===a.id} onClick={()=>review(a,'bonus')}>Marcar fundamentación lograda</button>}</>}{!a.reasoning&&a.game!=='desarrollo'&&!(a.game==='rosco'&&a.result==='wrong')&&!a.manual&&<span>Sin revisión marcada</span>}</td></tr>})}</tbody></table></div><div className="teacher-pagination actions" style={{justifyContent:'space-between',marginTop:20}}><button className="btn outline" disabled={visiblePage===0} onClick={()=>setPage(p=>Math.max(0,p-1))}><ChevronLeft size={15}/> Anteriores</button><span>Registros {visiblePage*pageSize+1}–{Math.min((visiblePage+1)*pageSize,rows.length)} de {rows.length}</span><button className="btn outline" disabled={visiblePage===maxPage} onClick={()=>setPage(p=>p+1)}>Siguientes <ChevronRight size={15}/></button></div></>}
    </div>
    <div className="analytics-box" style={{marginTop:25}}><h3>Lectura por unidad</h3><p>Resultados de la selección actual. Cada intento cuenta, incluidas las repeticiones.</p>{[1,2,3,0].map(u=>{const pendingUnit=rows.filter(a=>a.unit===u&&a.result==='pending').length,records=rows.filter(a=>a.unit===u&&a.result!=='pending'),ok=records.filter(a=>a.result==='correct').length;return <div className="unit-bar" key={u}><div><span>{u?'Unidad '+u:'Cruces entre unidades'}</span><b>{records.length?Math.round(ok/records.length*100)+'%':'—'}</b></div><div className="bar"><i style={{width:`${records.length?ok/records.length*100:0}%`}}/></div><small>{ok} aciertos / {records.length} intentos con corrección automática{pendingUnit?' · '+pendingUnit+' desarrollos sin nota automática':''}</small></div>})}</div>
    <p className="note">Esta actividad es de repaso: los aciertos y los recorridos no generan una nota automática. Las fundamentaciones y los desarrollos requieren lectura docente. Los desarrollos no entran en los porcentajes de aciertos; marcar su lectura no les asigna una nota. El CSV incluye todos los intentos de la sala, sus identificadores, preguntas completas, fragmentos, respuestas, versiones de los desarrollos, autoevaluaciones, fundamentaciones, identificadores anónimos y marcas de revisión. No se pide ni se exporta nombre o comisión; los registros anteriores se conservan sin borrarlos.</p>
   </>}
  </section>}
 </>
}
