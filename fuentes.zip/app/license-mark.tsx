import {assetURL} from './runtime-config';

export default function LicenseMark(){return <div className="license-mark">
 <div><strong>La kermés de las Ciencias Sociales</strong><span>Repaso y cierre de Introducción a las Ciencias Sociales</span></div>
 <a className="cc-license" rel="license" href="https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es" target="_blank" aria-label="Creative Commons CC BY-NC-SA 4.0 de Serafin Gonzalez y Emilia Correa"><span className="cc-icons" aria-hidden="true">{['cc','by','nc','sa'].map(icon=><img key={icon} src={assetURL('/license/'+icon+'.svg')} alt="" width="20" height="20"/>)}</span><span className="cc-attribution"><b>CC BY-NC-SA 4.0</b><span>© 2026 Serafin Gonzalez y Emilia Correa</span><span>Adscripto y Adscripta</span></span></a>
 <small>Los contenidos didácticos propios de Serafin Gonzalez y Emilia Correa se pueden compartir y adaptar con crédito a ambos, sin fines comerciales y bajo la misma licencia. Las imágenes, los textos citados, el código y los aportes del muro conservan sus propios derechos.</small>
</div>}
