import {assetURL} from './runtime-config';

export default function LicenseMark(){return <div className="license-mark">
 <div><strong>Serafin Gonzalez - Adscripto</strong><span>La kermés de las Ciencias Sociales · 2026</span><span>¿Quién lo diría? y guías: Emilia Correa - Adscripta</span></div>
 <a className="cc-license" rel="license" href="https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es" target="_blank"><span className="cc-icons" aria-hidden="true">{['cc','by','nc','sa'].map(icon=><img key={icon} src={assetURL('/license/'+icon+'.svg')} alt="" width="20" height="20"/>)}</span><b>CC BY-NC-SA 4.0</b></a>
 <small>Contenido didáctico propio: compartir y adaptar con crédito, sin fines comerciales y bajo la misma licencia. El recurso aportado por Emilia Correa, las imágenes, los textos citados, el código y los aportes del muro conservan sus propios derechos.</small>
</div>}
