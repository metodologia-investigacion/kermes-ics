// The hosted application uses its own API. The static export supplies these
// public build constants; authentication always stays in browser storage.
declare const __ICS_API_ORIGIN__: string;
declare const __ICS_ASSETS__: Record<string,string>;

const apiOrigin=typeof __ICS_API_ORIGIN__==='undefined'?'':__ICS_API_ORIGIN__;
export const classroomURL=(query='')=>apiOrigin+'/api/classroom'+query;
export const siteURL=()=>new URL('.',location.href).href;
export const assetURL=(path:string)=>typeof __ICS_ASSETS__!=='undefined'?__ICS_ASSETS__[path]||path:path;
